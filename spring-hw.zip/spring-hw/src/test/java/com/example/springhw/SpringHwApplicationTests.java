package com.example.springhw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
